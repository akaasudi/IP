function save(){
    let sub=document.getElementById("sub");
    let end=document.getElementById("end");
    end.innerHTML="DONE!"
    console.log("hii");
}