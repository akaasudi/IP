# ToDo-List
CRUD operation implementation to make simple ToDoList
<h3> Tech Stack : HTML | PUG | Express JS | Node JS | MongoDB | Heroku | MONGODB ATLAS</h3></br>
<h5>Features includes : </h5>


![WhatsApp Image 2020-09-15 at 12 16 26 AM](https://user-images.githubusercontent.com/55989361/93126579-26aeee00-f6ea-11ea-9161-6346ab7fed61.jpeg)
![WhatsApp Image 2020-09-15 at 12 16 26 AM (1)](https://user-images.githubusercontent.com/55989361/93126490-07b05c00-f6ea-11ea-89d7-18f75bcf47c2.jpeg)


![WhatsApp Image 2020-09-15 at 12 16 26 AM (2)](https://user-images.githubusercontent.com/55989361/93126634-3f1f0880-f6ea-11ea-8ed4-bbd0f17cb904.jpeg)

![WhatsApp Image 2020-09-15 at 12 16 27 AM](https://user-images.githubusercontent.com/55989361/93126705-552cc900-f6ea-11ea-97da-453796be9ba2.jpeg)

![WhatsApp Image 2020-09-15 at 12 16 27 AM (1)](https://user-images.githubusercontent.com/55989361/93126766-6d9ce380-f6ea-11ea-81c2-3f5285b695db.jpeg)


<h3>Steps to have the app running on your local server</h3>
<ul>
<li>Fork and clone the repository.</li>
<li>Open Terminal in the cloned directory.</li>
 <li>hit npm i(install npm)</li>
<li>Now you can run the To-Do list on your machine.Remember,prior to doing that you need to create a mongo db and add it to the index.js file or use my own DB.</li>
<li>After completing the above steps, run node index.js in the terminal along with that,hit mongod in another terminal. After few mins it will start on the browser and you are good to go!</li>
 </ul> 
